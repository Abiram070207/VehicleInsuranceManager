package exceptions;
public class InvalidPolicyException extends Exception {
    public InvalidPolicyException(String msg) { super(msg); }
}
