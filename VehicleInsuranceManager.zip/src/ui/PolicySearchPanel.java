package ui;
import javax.swing.*;
public class PolicySearchPanel extends JPanel {
    public PolicySearchPanel() {
        add(new JLabel("(Search UI stub)")); // Expand as needed
    }
}
