package utils;
import java.sql.*;
public class DatabaseHandler {
    public static Connection connect() throws Exception {
        // Optional JDBC: user must provide driver & DB. Returning null as stub.
        return null;
    }
}
